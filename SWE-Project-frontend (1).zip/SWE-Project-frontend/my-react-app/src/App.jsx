// import Order from './order/Order'
// import MenuPage from './menuPage/firstPage/MenuPage'
// import Appetizers from './menuPage/fullMenu/appetizers/Appetizers'
// import MainDishes from './menuPage/fullMenu/mainDishes/mainDishes'
// import SignatureDishes from './menuPage/fullMenu/signatureDishes/SignatureDishes'
// import FullMenu from './menuPage/fullMenu/fullMenu'
// import PaymentPage from './paymentPage/paymentPage'
// import CustomerRegistrationForm from './Register Page/CustomerRegForm'; // Adjust the path as necessary
// import ManagerRegistrationForm from './Register Page/ManagerRegForm';
// import AddDeposit from "./insufficient funds/addDepoist"
// import InsufficientFunds from "./insufficient funds/insufficient"
// import HomeScreen from './HomeScreen/HomeScreen'
// import VIPUser from './HomeScreen/VIPHomeScreen'
// import AddDeposit from './insufficient funds/addDepoist'
// import Complaints from "./Complaints/Urgent"
// import Important from './Complaints/Important'
// import Reservation from './Register Page/ReservationForm'
// import LoginForm from "./login/loginPage"
// use this file to make sure your components work
// import Complaintso from './Complaints/complimentorComplain'
// import Complainabout   from './Complaints/complainabt'
// import Deregister from './Deregister/Deregister'

// import RegistrationPage from "./pages/RegistrationPage";
// import DeliveryMenRegistration from "./pages/DeliveryMenRegistration";
// import ManagerRegistration from "./pages/ManagerRegistration";
// import ReportPage from "./pages/ReportPage";
// import ReviewPage from "./pages/ReviewPage";
// import ComplainSuccessPage from "./pages/ComplainSuccessPage";
// import ComplimentSuccessPage from "./pages/ComplimentSuccessPage";
// import DiscussionPage from "./pages/DiscussionPage";
// import LastPage from "./pages/LastPage";
// import MenuPage from "./pages/MenuPage";
// import PaymentDetailsPage from "./pages/PaymentDetailsPage";
// import OrderConfirmationPage from "./pages/OrderConfirmationPage";
// import OrderPrompt from "./pages/OrderPrompt";
// import ManagerPD from './managers/pages/ManagerAction'
          

const App = () => {
  return (
    <div>
//       <RegistrationPage />
//       <ManagerRegistration />
//       <DeliveryMenRegistration />
//       <ReviewPage />
//       <ReportPage />
//       <OrderConfirmationPage />
//       <ComplainSuccessPage />
//       <ComplimentSuccessPage />
//       <DiscussionPage />
//       <LastPage />
//       <OrderPrompt />
//       <MenuPage />
//       <PaymentDetailsPage />
    </div>
  );
};

export default App;
