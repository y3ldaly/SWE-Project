const LastPage = () => {
  return (
    <div className="page last__page">
      <div className="container">
        <h1 className="heading">We’re sad to see you go!</h1>
        <h2 className="subheading">مع السلامه يا زفت </h2>
      </div>
    </div>
  );
};

export default LastPage;
