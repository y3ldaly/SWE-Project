import Form from "../components/Form"
import UserNavbar from '../components/UserNavbar' 

function CustomerReportPage2() {
    return(
        <>
            <UserNavbar/>
            <Form caption="Write your report on this comment here. The customer will 
            be identified and
            warned if their comment is deemed inappropriate by the manager:" title="" option1="" option2="" option3=""/>
            
        </>
    )
}

export default CustomerReportPage2