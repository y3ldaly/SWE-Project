import Form from "../registered/components/Form"
import UserNavbar from '../registered/components/UserNavbar' 

function ChefComplimentPage() {
    return(
        <>
            <UserNavbar/>
            <Form caption="Compliment the importer here:" title="Importers" option1="Some Dude" option2="Joe Mama"/>
            
        </>
    )
}

export default ChefComplaintPage